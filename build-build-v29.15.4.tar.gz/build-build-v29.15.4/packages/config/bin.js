#!/usr/bin/env node

// This is a workaround for npm issue: https://github.com/npm/cli/issues/2632

import './lib/bin/main.js'
